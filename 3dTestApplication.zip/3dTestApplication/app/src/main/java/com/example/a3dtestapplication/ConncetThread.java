package com.example.a3dtestapplication;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothSocket;

public class ConncetThread extends Thread {
    //private final BluetoothSocket mmSocket;
    //private final BluetoothAdapter mmDevice;


}
